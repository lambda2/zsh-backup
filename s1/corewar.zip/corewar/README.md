_42_corewar
===========
