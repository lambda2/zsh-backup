#!/bin/bash

for i in `ls tests/ `
do
	for j in `ls tests/$i/*.s`
	do
		echo "RUNNING [./$j]"
		./asm ./$j 2 >> test.result ;
	done;
	#cat ./tests/$i/test.result;
	echo "END OF TESTS"
	#rm ./tests/$i/test.result;
done;
