/*
** verif.c for corewar in /home/ecormi_p/crw-vm-asm/asm
**
** Made by pierre ecormier
** Login   <ecormi_p@epitech.net>
**
** Started on  Fri Mar 23 09:20:36 2012 pierre ecormier
** Last update Fri Mar 23 09:27:07 2012 pierre ecormier
*/

#include	<stdio.h>
#include	<stdlib.h>
#include	"corewar.h"
#include	"my.h"

static void	aff_error(char *what_it_is, char *s, char *wrong_thing)
{
	my_putstr("Error: Wrong ");
	my_putstr(what_it_is);
	my_putstr(" for \"");
	my_putstr(wrong_thing);
	my_putstr("\" @ line below :\n");
	my_putstr(s);
	my_putchar('\n');
	exit(0);
}

/*
 * Va verifier que le label contenu dans s est valide.
 * CAD que ses chars sont dans LABEL_CHARS et que le premier char n'est pas un
 * nombre.
 * @error: dans le while, le LABEL_CHAR n'est pas obligatoirement ':'
 */
static void	verif_label(char *s)
{
	int		i;
	int		y;

	i = y = 0;
	while (s[i] && s[i] != ':') // pas obligatoirement ':'
	{
		if (i == 0 && (ISNUM(s[i]))) // premier char est un num
			aff_error("label (number as first char)", s, s + i);
		while (LABEL_CHARS[y] && LABEL_CHARS[y] != s[i])
			y++;
		if (!LABEL_CHARS[y])
			aff_error("label (invalid char)", s, s + i);
		y = 0;
		i++;
	}
	if (s[i] == 0 || s[i + 1] != 0) // char after label
		aff_error("label (char after \':\')", s, s + i);
	if (i == 0) // pas de nom au label
		aff_error("label (no name)", s, s);
}

/*
 * va regarder si la chaine CONTIENT un label
 * (ce n'est donc pas necessairement le premier char)
 */
int		is_label(char *str)
{
	int		i;

	i = 0;
	while (str[i])
	{
		if (str[i] == LABEL_CHAR)
		{
			verif_label(str);
			return (1);
		}
		i++;
	}
	return (0);
}

void		verif_args(t_asmline *line, char *s)
{
	int		nbr_arg;
	int		is_reg;

	nbr_arg = 0;

	/*
	 * va mettre nbr_arg = aux nombre d'args presents dans line->argv.
	 */
	while (nbr_arg <= 3 && line->argv[nbr_arg])
		nbr_arg++;

	/*
	 * Va check que le nombre d'arguments ne depasse pas le max autorise pour
	 * le type d'instruction associe dans op_tab.
	 */
	if (op_tab[line->code - 1].nbr_args != nbr_arg)
		aff_error("number of arguments", s, op_tab[line->code - 1].mnemonique);

	nbr_arg = 0;
	/*
	 * Ensuite, pour chaque argument
	 */
	while (nbr_arg <= 3 && line->argv[nbr_arg])
	{
		is_reg = 0;
		if ((line->type[nbr_arg] & T_LAB) > 0)
		{
			is_reg = 1;
			line->type[nbr_arg] = T_DIR;
		}
		if ((op_tab[line->code - 1].type[nbr_arg] & line->type[nbr_arg]) == 0)
			aff_error("type of argument", s, line->argv[nbr_arg]);
		if (is_reg)
			line->type[nbr_arg] = T_LAB;
		nbr_arg++;
	}
}

/*
 * Si on est sur le nom ou la definition du programme,
 * copie ce qu'il faut dans le [asmline] et renvoie 1, sinon renvoie 0
 */
int		is_definition(t_asmline *line, char *s, char **words)
{
	int		i;

	get_code(words, line, &s); // met a jour le code de [line] (-2, -3 ou 0)
	if (line->code != 0) // si on a le nom ou la definition
	{
		while (*s && *(s - 1) != '\"') // on avance jusque aux quotes
			s++;
		line->argv[0] = malloc(my_strlen(s) + 1); // on reserve la place
		if (!line->argv[0])
			exit (0);
		i = 0;
		while (*s && *s != '\"') // on copie le nom ou le commentaire
		{
			line->argv[0][i] = *s;
			s++;
			i++;
		}
		line->argv[0][i] = 0; // on met le /0 de fin de chaine
		line->argv[1] = NULL; // on met le NULL de fin de tableau
		return (1); // all's right
	}
	return (0); // all's WRONG
}
