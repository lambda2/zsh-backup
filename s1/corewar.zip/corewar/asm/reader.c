/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   reader.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lambda2 <aaubin@student.42.fr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/21 00:16:44 by lambda2           #+#    #+#             */
/*   Updated: 2014/01/21 00:17:08 by lambda2          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "asm.h"

int					ft_check_name(char *s, t_instruction *curr, char **parts)
{
	if (inst_set_code(parts, &s, curr))
	{
		s += ft_strpos(s, "\"") + 1;
		curr->params[0] = ft_strsub(s, 0, ft_strpos(s, "\""));
		return (1);
	}
	else
	{
		return (0);
	}
}

int					ft_decode_line(char *s, t_instruction *current, int line)
{
	char				**parts;
	int				ctr;

	current->line = line;
	current->full_line = ft_strdup(s);
	ctr = 0;
	while (s[ctr])
	{
		if (s[ctr] == COMMENT_CHAR || s[ctr] == ';') // unofficial inline ?
			s[ctr--] = '\0';
		ctr++;
	}
	parts = ft_asmsplit(s);
	if (!parts || !*parts)
	{
		return (0);
	}
	else if (*parts && ft_check_name(s, current, parts))
	{
		// debug printfs... to remove.
		// ====================================================================
		if (current->i_type == NAME)
			printf("## NAME :\n\t%s\n", current->params[0]);
		else if (current->i_type == COMMENT)
			printf("## COMMMENT :\n\t%s\n", current->params[0]);
		// ====================================================================
	}
	else
	{
		// debug printfs... to remove.
		// ====================================================================
		ctr = 0;
		printf("\n[decoding] %s\n{\n", s);
		while (parts && parts[ctr])
		{
			printf("\t - [%s]\n", parts[ctr]);
			ctr++;
		}
		printf("}\n");
		// ====================================================================
		if (!update_inst(parts, current))
			return (0);
		return (1);
	}
	return (0);
}

int					ft_read_source(char *path)
{
	int				fd;
	t_instruction	*root;
	t_instruction	*current;
	char				*s;
	int				line;

	line = 0;
	root = create_instruction();
	current = root;
	if ((fd = open(path, O_RDONLY)) == -1)
		return (READ_ERROR);
	while (++line && current && get_next_line(fd, &s))
	{
		ft_decode_line(s, current, line);
		current->next = create_instruction();
		current = current->next;
	}
	close(fd);
	prepare_file(root, path);
	return (1);
}

void					ft_read_sources(int c, char **v)
{
	int				file_count;

	file_count = 1;
	while (file_count < c)
	{
		ft_read_source(v[file_count]);
		file_count++;
	}
}
