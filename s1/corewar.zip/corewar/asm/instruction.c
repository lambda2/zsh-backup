/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   instruction.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lambda2 <aaubin@student.42.fr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/21 00:16:44 by lambda2           #+#    #+#             */
/*   Updated: 2014/01/21 00:17:08 by lambda2          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "asm.h"

t_instruction		*create_instruction(void)
{
	int				ct;
	t_instruction	*inst;

	ct = 0;
	inst = (t_instruction *)ft_memalloc(sizeof(t_instruction));
	if (inst)
	{
		inst->next = NULL;
		inst->i_type = NONE;
		inst->opcode = 0;
		while (ct < MAX_ARGS_NUMBER)
		{
			inst->type[ct] = 0;
			inst->params[ct] = NULL;
			ct++;
		}
	}
	return (inst);
}

int					inst_set_code(char **elts, char **s, t_instruction *self)
{
	if (ft_strequ(NAME_CMD_STRING, elts[0]))
	{
		if (ft_strlen(*s) > (ft_strlen(NAME_CMD_STRING) + PROG_NAME_LENGTH))
			ft_error(NAME_TOO_LONG, *s, self->line);
		self->i_type = NAME;
		(*s) = (*s) + ft_strlen(NAME_CMD_STRING);
	}
	else if (ft_strequ(COMMENT_CMD_STRING, elts[0]))
	{
		self->i_type = COMMENT;
		(*s) = (*s) + ft_strlen(COMMENT_CMD_STRING);
	}
	else
	{
		return (0);
	}
	return (1);
}

int					inst_retreive_code(char *zero, t_instruction *self)
{
	int		counter;

	counter = 0;
	while (op_tab[counter].code)
	{
		if (ft_strequ(zero, op_tab[counter].mnemonique))
		{
			self->opcode = op_tab[counter].code;
		}
		counter++;
	}
	if (!self->opcode)
		ft_error(MNEMONIQUE, self->full_line, self->line);
	return (self->opcode != 0);
}

int					update_inst(char **parts, t_instruction *self)
{
	char				*label;

	if (parts && *parts && ft_check_label(*parts, self))
	{
		self->i_type = LABEL;
		self->opcode = -1;
		label = ft_strdup(*parts);
		ft_update_inst_params(parts, self);
		self->params[0] = label;
	}
	else if (parts && parts[0] && parts[1])
	{
		self->i_type = OP;
		inst_retreive_code(parts[0], self);
		ft_parse_inst_type(parts + 1, self);
		ft_update_inst_params(parts + 1, self);
	}
	else
		return (0);
	return (ft_check_args_are_valid(self));
}
