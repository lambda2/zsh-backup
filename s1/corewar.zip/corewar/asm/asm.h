/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   asm.h                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lambda2 <aaubin@student.42.fr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/21 00:16:44 by lambda2           #+#    #+#             */
/*   Updated: 2014/01/21 00:17:08 by lambda2          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ASM_H
# define ASM_H

# include "libft.h"
# include "libft/includes/libft.h"
# include "get_next_line.h"
# include "op.h"

#define	READ_ERROR	-1

/*
** x is a numeric char
*/
#define	ISNUM(x)	((x) >= '0' && (x) <= '9')

/*
** x is an uppercase alpha hexa char
*/
#define	ISHMAX(x)	((x) >= 'A' && (x) <= 'F')

/*
** x is a lowercase alpha hexa char
*/
#define	ISHMIN(x)	((x) >= 'a' && (x) <= 'f')

/*
** x is a hexa char
*/
#define	ISHEX(x)	(ISNUM(x) || ISHMAX(x) || ISHMIN(x))

/*
** convert hexadecimal char x to decimal char
*/
#define	HEX_TO_DEC(x) (ISNUM(x) ? (x) - 48 : (ISHMIN(x) ? (x) - 87 : (x) - 55))

/*
** x is a sign (- or +)
*/
#define	IS_SIGN(x) ((x) == '-' || (x) == '+')

/*
** x is a space, a tab, or a separator char (defined in op.h)
*/
#define	IS_SPACE(x) ((x) == ' ' || (x) == '\t' || (x) == SEPARATOR_CHAR)

/*
** The error codes
*/
typedef	enum					e_error_code
{
	NO_ERROR,
	NAME_TOO_LONG,
	COMMENT_TOO_LONG,
	LABEL_NUM,
	LABEL_INV_CHAR,
	LABEL_CHAR_AFTER,
	LABEL_NO_NAME,
	MNEMONIQUE,
	PARAMS_COUNT,
	ARG_TYPE
}							t_error_code;

/*
** The main error structure.
*/
typedef	struct				s_error
{
	char						*thing;
	int						line;
	t_error_code				code;
}							t_error;

/*
** Will define the type of the current t_instruction.
** Can be an header's name / comment, a label or an operand.
*/
typedef	enum					e_instruction_type
{
	NAME,
	COMMENT,
	LABEL,
	OP,
	NONE
}							t_instruction_type;

/*
** This structure represents an instruction.
*/
typedef	struct				s_instruction
{
	int						line;
	struct s_instruction		*next;
	char						*full_line;
	char						type[MAX_ARGS_NUMBER];
	char						opcode;
	t_instruction_type		i_type;
	int						size;
	char						*params[MAX_ARGS_NUMBER];
	unsigned char			code[20];
}							t_instruction;

/*
** Will read the content of the ".s" file(s) contained in v (aka argv)
** and create their associated ".cor" hexa files.
*/
void					ft_read_sources(int c, char **v);

/*
** Will create the ".cor" file for the given ".s" file (by the path)
*/
int					ft_read_source(char *path);

/*
** Will malloc and init a new t_instruction
*/
t_instruction		*create_instruction(void);

/*
** Will set the good (i_)type for the given instruction.
*/
int					inst_set_code(char **elts, char **s, t_instruction *self);

/*
**
*/
int					update_inst(char **parts, t_instruction *self);
void					ft_update_inst_params(char **part, t_instruction *self);
void					ft_parse_inst_type(char **part, t_instruction *self);
void					ft_parse_inst_args(char **part, t_instruction *self);

/*
** Will decode the current line informations and put them into the given
** t_instruction structure.
*/
int					ft_decode_line(char *s, t_instruction *current, int line);

/*
** An [asm] dedicaced strsplit. Will cut the given char on ' ', '\t' and
** SEPARATOR_CHAR.
*/
char					**ft_asmsplit(char const *s);

/*
** ============================== Write functions ==============================
*/
void					prepare_file(t_instruction *root, char *path);

/*
** ============================== Verif functions ==============================
*/

int					ft_check_args_are_valid(t_instruction *self);

/*
** ============================== Utils functions ==============================
*/

/*
** Will check if the given string is a label.
** If it's the case, will chek that the given label is valid
** and will kill the program if an error occurs.
*/
int					ft_check_label(char *s, t_instruction *ins);

/*
** ============================= Error functions ===============================
*/

/*
** Will set an error.
*/
void					ft_error(t_error_code e, char *thing, int line);

/*
** If there is an error setted, will display it and exit the program.
*/
void					ft_print_error(void);

#endif /* !ASM_H */
