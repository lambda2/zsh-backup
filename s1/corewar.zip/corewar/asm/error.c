/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   error.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lambda2 <aaubin@student.42.fr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/21 00:16:44 by lambda2           #+#    #+#             */
/*   Updated: 2014/01/21 00:17:08 by lambda2          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "asm.h"

static t_error				*get_error(void)
{
	static t_error			*e;

	if (e == NULL)
	{
		e = (t_error *)ft_memalloc(sizeof(t_error));
		e->code = NO_ERROR;
		e->line = 0;
		e->thing = NULL;
	}
	return (e);
}

static char					*ft_get_error_message(t_error_code e)
{
	if (e == LABEL_NUM)
		return ("number as the first char of a label");
	else if (e == LABEL_INV_CHAR)
		return ("invalid char in the label");
	else if (e == LABEL_CHAR_AFTER)
		return ("there is a char directly after a label");
	else if (e == LABEL_NO_NAME)
		return ("label don't have a name");
	else if (e == MNEMONIQUE)
		return ("no such mnemonique");
	else if (e == PARAMS_COUNT)
		return ("incorrect number of args");
	else if (e == ARG_TYPE)
		return ("wrong argument type");
	else
		return ("");
}

void							ft_error(t_error_code e, char *thing, int line)
{
	t_error					*err;

	err = get_error();
	err->code = e;
	err->thing = thing;
	err->line = line;
	ft_print_error();
}

void							ft_print_error(void)
{
	t_error					*err;

	err = get_error();
	if (err && err->code != NO_ERROR)
	{
		ft_putstr_fd("Error: ", 2);
		ft_putstr_fd(ft_get_error_message(err->code), 2);
		ft_putstr_fd(" ('", 2);
		ft_putstr_fd(err->thing, 2);
		ft_putstr_fd("') at line ", 2);
		ft_putnbr_fd(err->line, 2);
		ft_putendl_fd(".", 2);
		exit(0);
	}
}
