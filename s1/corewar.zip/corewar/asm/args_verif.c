/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   args_verif.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lambda2 <aaubin@student.42.fr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/21 00:16:44 by lambda2           #+#    #+#             */
/*   Updated: 2014/01/21 00:17:08 by lambda2          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "asm.h"

static int				ft_get_params_count(t_instruction *self)
{
	int					count;

	count = 0;
	while (count <= MAX_ARGS_NUMBER && self->params[count])
		count++;
	return (count);
}

int						ft_check_args_are_valid(t_instruction *self)
{
	int					counter;
	int					params_count;
	int					reg;

	if (self->opcode > 0 && self->i_type == OP)
	{
		counter = 0;
		params_count = ft_get_params_count(self);
		/* !!!
		printf("%s have %d args and require %d args !\n", op_tab[self->opcode - 1].mnemonique,
			   params_count, op_tab[self->opcode - 1].nbr_args);
		*/
		if (op_tab[self->opcode - 1].nbr_args != params_count)
			ft_error(PARAMS_COUNT, self->full_line, self->line);
		while (counter < params_count)
		{
			reg = 0;
			if ((T_LAB & self->type[counter]) > 0)
			{
				reg = 1;
				self->type[counter] = T_DIR;
			}
			/* !!!
			printf("op_tab[%d].type[%d] & self->type[%d] = %d & %d = %d\n",
				   self->opcode - 1, counter, counter, (op_tab[self->opcode - 1].type[counter]),
					self->type[counter], (op_tab[self->opcode - 1].type[counter] & self->type[counter]));
			*/
			if ((op_tab[self->opcode - 1].type[counter] & self->type[counter]) == 0)
				ft_error(ARG_TYPE, self->full_line, self->line);
			if (reg)
				self->type[counter] = T_LAB;
			counter++;
		}
	}
	return (1);
}
