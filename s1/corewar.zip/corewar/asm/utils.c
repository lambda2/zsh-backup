/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lambda2 <aaubin@student.42.fr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/21 00:16:44 by lambda2           #+#    #+#             */
/*   Updated: 2014/01/21 00:17:08 by lambda2          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "asm.h"

int							ft_check_label(char *s, t_instruction *ins)
{
	int						i;

	if (ft_strchr(s, LABEL_CHAR) == NULL)
	{
		return (0);
	}
	else
	{
		i = 0;
		while (s[i] && s[i] != LABEL_CHAR)
		{
			if (!i && ( ISNUM( s[i] ) ))
				ft_error(LABEL_NUM, s, ins->line);
			else if (strchr(LABEL_CHARS, s[i]) == NULL)
				ft_error(LABEL_INV_CHAR, s, ins->line);
			i++;
		}
		if (s[i] == 0 || s[i + 1] != 0)
			ft_error(LABEL_CHAR_AFTER, s, ins->line);
		else if (i == 0)
			ft_error(LABEL_NO_NAME, s, ins->line);
		ft_print_error();
		return (1);
	}
}

