/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   writer.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lambda2 <aaubin@student.42.fr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/21 00:16:44 by lambda2           #+#    #+#             */
/*   Updated: 2014/01/21 00:17:08 by lambda2          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "asm.h"

static char				*get_program_name(t_instruction *root)
{
	char				*name;

	name = ft_strnew(PROG_NAME_LENGTH);
	ft_bzero(name, PROG_NAME_LENGTH);
	while (root)
	{
		if (root->i_type == NAME)
		{
			ft_strcpy(name, root->params[0]);
		}
		root = root->next;
	}
	return (name);
}

static char				*get_program_cmt(t_instruction *root)
{
	char				*cmt;

	cmt = ft_strnew(COMMENT_LENGTH);
	ft_bzero(cmt, COMMENT_LENGTH);
	while (root)
	{
		if (root->i_type == COMMENT)
		{
			ft_strcpy(cmt, root->params[0]);
		}
		root = root->next;
	}
	return (cmt);
}

static void				launch_magic_powers(t_instruction *root, char *(*header))
{
	char				*name;
	int					total_size;
	int					counter;

	counter = 0;
	total_size = sizeof(int) + PROG_NAME_LENGTH;
	name = get_program_name(root);
	while (counter < total_size)
	{
		if (counter < sizeof(int))
		{
			(*header)[counter] = COREWAR_EXEC_MAGIC >> 24;
			(*header)[++counter] = COREWAR_EXEC_MAGIC >> 16;
			(*header)[++counter] = COREWAR_EXEC_MAGIC >> 8;
			(*header)[++counter] = COREWAR_EXEC_MAGIC;
		}
		else if (counter < (sizeof(int) + PROG_NAME_LENGTH))
				(*header)[counter] = *name++;
		else
			(*header)[counter] = 0x0;
		counter++;
	}
}

char					*prepare_header(t_instruction *root)
{
	char				*comment;
	int					total_size;
	int					counter;
	int					c_counter;
	char				*header;

	c_counter = 0;
	total_size = sizeof(int) + PROG_NAME_LENGTH + COMMENT_LENGTH + 1;
	header = (char *)ft_strnew(total_size);
	comment = get_program_cmt(root);
	counter = sizeof(int) + PROG_NAME_LENGTH + 1;
	launch_magic_powers(root, &header);
	while (counter < total_size)
	{
		header[counter++] = comment[c_counter++];
	}
	return (header);
}

void					prepare_file(t_instruction *root, char *path)
{
	int					fd;
	int					size;

	size = sizeof(int) + PROG_NAME_LENGTH + COMMENT_LENGTH;
	fd = open(ft_strjoin(path, ".out"), O_WRONLY | O_CREAT | O_TRUNC, 0644);
	write(fd, prepare_header(root), size);
	close(fd);
	ft_putendl("output created !");
}
