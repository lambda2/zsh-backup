/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   args_parser.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lambda2 <aaubin@student.42.fr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/21 00:16:44 by lambda2           #+#    #+#             */
/*   Updated: 2014/01/21 00:17:08 by lambda2          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "asm.h"

void				ft_update_inst_params(char **part, t_instruction *self)
{
	int			i;

	i = 0;
	while (i < MAX_ARGS_NUMBER && part[i] && part[i][0])
	{
		if (part[i][0] == DIRECT_CHAR || part[i][0] == 'r' )
			part[i] = part[i] + 1;
		self->params[i] = part[i];
		i++;
	}
	if (i < MAX_ARGS_NUMBER)
		self->params[i] = NULL;
}

void				ft_parse_inst_type(char **part, t_instruction *self)
{
	int			i;

	i = 0;
	while (i < MAX_ARGS_NUMBER && part[i] && part[i][0])
	{
		if (part[i][0] == 'r')
			self->type[i] = T_REG;
		else if (part[i][0] == DIRECT_CHAR)
		{
			if (part[i][1] == LABEL_CHAR)
				self->type[i] = T_LAB;
			else
				self->type[i] = T_DIR;
		}
		else
			self->type[i] = T_IND;
		i++;
	}
	while (i < MAX_ARGS_NUMBER)
	{
		self->type[i] = 0;
		i++;
	}
}

void				ft_parse_inst_args(char **part, t_instruction *self)
{
	int			i;

	i = 0;
	while (i < MAX_ARGS_NUMBER && part[i] && part[i][0])
	{
		if (part[i][0] == 'r' || part[i][0] == DIRECT_CHAR)
			part[i] = part[i] + 1;
		self->params[i] = part[i];
		i++;
	}
	if (i < MAX_ARGS_NUMBER)
		self->params[i] = NULL;
}
