#/bin/bash

for i in `ls *.s`
do
	echo "RUNNING [$i]"
	../../asm $i 2>>test.result ;
done;
pwd
cat test.result;
echo "END OF TESTS"
rm test.result;
