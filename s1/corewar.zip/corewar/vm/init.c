/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbenhabb <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/12 00:55:09 by sbenhabb          #+#    #+#             */
/*   Updated: 2014/01/12 06:19:31 by sbenhabb         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "vm.h"

t_vm		*init(void)
{
	t_vm		*vm;

	vm = (t_vm *) malloc(sizeof(t_vm));
	if (!vm)
		exit(-1);
	vm->memory = ft_memalloc(MEM_SIZE + 1);
	vm->champions = ft_memalloc(MAX_PLAYERS * sizeof(t_champion));
	if (!vm->memory || !vm->champions)
	{
		write(2, "Malloc failed\n", 14);
		exit(-1);
	}
	vm->total_rounds = 0;
	vm->round = 0;
	vm->lives = 0;
	vm->cycles_to_die = CYCLE_TO_DIE;
	vm->processes = 0;
	vm->dump_threshold = -2;
	return (vm);
}

t_vm		*parser(int argc, char **argv, t_vm *vm)
{
	int			i;
	int			champions;

	i = 1;
	champions = 0;
	while (i < argc)
	{
		if (ft_strcmp(argv[i], "-dump") == 0)
		{
			i++;
			vm->dump_threshold = ft_atoi(argv[i]);
		}
		else if (ft_strcmp(argv[i], "-n") == 0 && argv[i + 2])
		{
			i += 2;
			vm = add_champion(vm, champions, argv[i++], ft_atoi(argv[i - 1]));
			champions++;
		}
		else
		{
			vm = add_champion(vm, champions, argv[i++], -1);
			champions++;
		}
		i++;
	}
	return (vm);
}
