Corewar Virtual Machine
=======================

Les sources de la machine virtuelle du corewar. Quand il y en aura... :)
