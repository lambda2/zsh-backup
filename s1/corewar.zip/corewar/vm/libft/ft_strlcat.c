/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: piavisse <piavisse@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/22 14:46:00 by piavisse          #+#    #+#             */
/*   Updated: 2013/12/01 10:10:30 by sbenhabb         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t			ft_strlcat(char *dst, const char *src, size_t size)
{
	size_t		i;
	size_t		l;

	l = ft_strlen(dst);
	if (size < l)
		return (size + ft_strlen((char*) src));
	i = 0;
	while (src[i] != '\0' && l + i < size - 1)
	{
		dst[l + i] = src[i];
		i++;
	}
	dst[i + l] = '\0';
	return (l + ft_strlen((char*) src));
}
