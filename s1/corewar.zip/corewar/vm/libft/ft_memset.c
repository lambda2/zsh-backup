/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memset.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbenhabb <sbenhabb@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/19 14:21:33 by sbenhabb          #+#    #+#             */
/*   Updated: 2013/11/30 05:40:06 by sbenhabb         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memset(void *ptr, int value, size_t len)
{
	size_t		i;
	char		*str;

	str = ptr;
	i = 0;
	while (i < len)
	{
		str[i] = (char) value;
		i++;
	}
	return (ptr);
}
