/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_wordsplit.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbenhabb <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/23 18:48:13 by sbenhabb          #+#    #+#             */
/*   Updated: 2013/12/23 19:41:22 by sbenhabb         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	**ft_wordsplit(char *word, char delim)
{
	int		i;
	int		j;
	char	**split;

	i = ft_strlen(word);
	j = 0;
	while (j < i && word[j] != delim)
		j++;
	if (j == i || j == 0)
		return (0);
	split = (char **) malloc(sizeof(char *) * 2);
	split[0] = ft_strndup(word, j);
	split[1] = ft_strndup(word + j, i - j);
	return (split);
}
