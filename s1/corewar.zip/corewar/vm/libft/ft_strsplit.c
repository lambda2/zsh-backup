/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strsplit.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbenhabb <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/30 05:20:42 by sbenhabb          #+#    #+#             */
/*   Updated: 2014/01/11 23:13:15 by sbenhabb         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static char			*ft_wordnext(char *s, char c);
static int			ft_wordlen(const char *str, char c);
static char			**ft_emptystring(void);


char				**ft_strsplit(char const *s, char c)
{
	int			n;
	int			len;
	int			i;
	char		**words;

	n = ft_wordcount(s, c);
	if (n == 0)
		return (ft_emptystring());
	words = (char **) ft_memalloc(sizeof(char *) * ft_strlen(s));
	if (!words)
		return (0);
	i = 0;
	len = -1;
	while (i < n)
	{
		s = ft_wordnext((char *) s + len + 1, c);
		len = ft_wordlen(s, c);
		words[i] = (char *) ft_memalloc(sizeof(char *) * len);
		if (!words[i])
			return (0);
		ft_memcpy(words[i], (void *) s, len);
		i++;
	}
	return (words);
}

static char			**ft_emptystring(void)
{
	char		**str;

	str = (char **) ft_memalloc(sizeof(char *) * 1);
	*str = (char *) ft_memalloc(sizeof(char *) * 1);
	str[0] = 0;
	return (str);
}

static char			*ft_wordnext(char *s, char c)
{
	int			i;

	i = 0;
	if (!s)
		return (0);
	while (s[i] != 0 && s[i] == c)
		i++;
	return (s + i);
}

static int			ft_wordlen(const char *str, char c)
{
	int			i;

	i = 0;
	if (!str)
		return (0);
	while (str[i] != 0 && str[i] != c)
		i++;
	return (i);
}
