/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memccpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbenhabb <sbenhabb@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/20 04:41:17 by sbenhabb          #+#    #+#             */
/*   Updated: 2013/12/08 04:39:18 by sbenhabb         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memccpy(void *s1, const void *s2, int c, size_t n)
{
	const char	*s;
	char		*d;

	s = s2;
	d = s1;
	while (n-- > 0)
		if ((*d++ = *s++) == (const char) c)
			return (d);
	return (0);
}
