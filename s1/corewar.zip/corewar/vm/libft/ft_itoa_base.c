/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_itoa_base.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbenhabb <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/30 05:48:12 by sbenhabb          #+#    #+#             */
/*   Updated: 2013/12/12 16:58:46 by sbenhabb         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_itoa_base(int num, int base)
{
	int			i;
	char		*str;
	int			negative;

	str = (char *) ft_memalloc(sizeof(char *) * (ft_getpow(num) + 2));
	i = 0;
	negative = ft_isnegative(num);
	if (num == 0)
		str[i++] = '0';
	if (!negative && base == 10)
		num = -num;
	while (num != 0)
	{
		if (num % base > 9)
			str[i++] = (-(num % base) - 10 + 'A');
		else
			str[i++] = (char) (-(num % base) + 48);
		num = num / base;
	}
	if (negative)
		str[i++] = '-';
	str[i] = 0;
	return (ft_strrev(str));
}
