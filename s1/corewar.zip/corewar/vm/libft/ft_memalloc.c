/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memalloc.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbenhabb <sbenhabb@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/19 21:33:44 by sbenhabb          #+#    #+#             */
/*   Updated: 2013/11/30 05:46:52 by sbenhabb         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memalloc(size_t size)
{
	unsigned char	*ptr;

	if (size <= 0)
		return (0);
	ptr = (unsigned char *) malloc(sizeof(unsigned char) * size);
	if (ptr == NULL)
		return (0);
	ft_memset(ptr, 0, size);
	return (ptr);
}
