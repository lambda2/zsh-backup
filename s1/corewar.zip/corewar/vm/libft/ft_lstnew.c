/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstnew.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbenhabb <sbenhabb@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/20 22:56:24 by sbenhabb          #+#    #+#             */
/*   Updated: 2013/11/20 23:56:38 by sbenhabb         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

t_list	*ft_lstnew(void const *content, size_t content_size)
{
	t_list	*new;

	new = (t_list *) ft_memalloc(sizeof(t_list *));
	if (new)
	{
		new->content_size = content_size;
		if (content)
			new->content = *content;
		else
			new->content = 0;
		new->next = 0;
		return (new);
	}
	else
		return (0);
}
