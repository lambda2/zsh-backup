/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_realloc.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbenhabb <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/02 20:11:25 by sbenhabb          #+#    #+#             */
/*   Updated: 2013/12/08 05:30:59 by sbenhabb         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void		*ft_realloc(void *content, size_t s_size, size_t d_size)
{
	void	*copy;

	copy = ft_memalloc(d_size);
	if (copy)
	{
		ft_memcpy(copy, content, s_size);
		return (copy);
	}
	return (0);
}
