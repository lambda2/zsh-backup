/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbenhabb <sbenhabb@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/20 11:17:51 by sbenhabb          #+#    #+#             */
/*   Updated: 2013/11/24 14:32:40 by sbenhabb         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strjoin(char const *s1, char const *s2)
{
	size_t	len;
	char	*result;
	char	*result_save;

	len = ft_strlen(s1) + ft_strlen(s2);
	result = (char *) ft_memalloc(sizeof(char) * len + 1);
	if (result == 0)
		return (NULL);
	result_save = result;
	while (*s1)
		*result++ = *s1++;
	while (*s2)
		*result++ = *s2++;
	*result = 0;
	return (result_save);
}
