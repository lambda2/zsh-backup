/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strndup.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbenhabb <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/21 01:12:26 by sbenhabb          #+#    #+#             */
/*   Updated: 2013/12/23 19:40:54 by sbenhabb         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strndup(const char *s1, size_t max)
{
	char	*str;
	size_t	i;
	size_t	len;

	i = 0;
	len = ft_strlen(s1);
	if (len > max)
		str = (char *) ft_memalloc((len + 1) * sizeof(char));
	else
		str = (char *) ft_memalloc((max + 1) * sizeof(char));
	if (!str)
		return (0);
	while (s1[i] != 0 && i < max)
	{
		str[i] = s1[i];
		i++;
	}
	str[i] = 0;
	return (str);
}
