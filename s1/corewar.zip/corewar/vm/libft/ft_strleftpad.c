/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strleftpad.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbenhabb <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/12 18:41:16 by sbenhabb          #+#    #+#             */
/*   Updated: 2013/12/15 11:10:46 by sbenhabb         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strleftpad(char *str, int padding)
{
	int		i;
	int		j;
	int		k;
	char	*new;

	j = 0;
	k = 0;
	i = ft_strlen(str);
	new = ft_strnew(ft_max(i, padding));
	while (j < padding - i)
		new[j++] = ' ';
	while (k + j < ft_max(i, padding))
	{
		new[j + k] = str[k];
		k++;
	}
	free(str);
	new[j + k] = 0;
	return (new);
}
