/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_tohex.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbenhabb <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/12 03:41:27 by sbenhabb          #+#    #+#             */
/*   Updated: 2014/01/12 04:33:24 by sbenhabb         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_tohex(unsigned long int nb)
{
	return (ft_strrev(ft_tohex_base(nb)));
}

char	*ft_tohex_pre(unsigned long int nb)
{
	return (ft_strjoin("0x", ft_tohex(nb)));
}

char	*ft_tohex_base(unsigned long int nb)
{
	char	*str;
	int		i;

	str = ft_memalloc(2);
	i = nb % 16;
	str[0] = HEXTABLE[i];
	if (nb > 15)
		return (ft_strjoin(str, ft_tohex_base(nb / 16)));
	else
		return (str);
}
