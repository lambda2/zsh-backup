/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrev.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbenhabb <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/01 10:22:29 by sbenhabb          #+#    #+#             */
/*   Updated: 2013/12/12 23:47:37 by sbenhabb         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char		*ft_strrev(char *s)
{
	char	*ret;
	int		i;
	int		j;

	j = 0;
	i = ft_strlen(s) - 1;
	ret = (char *) ft_memalloc(sizeof(char *) * (i + 1));
	while (i >= 0)
	{
		ret[j] = s[i];
		i--;
		j++;
	}
	ret[j] = 0;
	return (ret);
}
