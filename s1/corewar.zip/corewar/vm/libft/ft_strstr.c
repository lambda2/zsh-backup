/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbenhabb <sbenhabb@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/20 09:03:47 by sbenhabb          #+#    #+#             */
/*   Updated: 2013/11/30 05:20:01 by sbenhabb         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strstr(const char *s1, const char *s2)
{
	int		i;

	i = 0;
	if (!s2)
		return ((char *) s1);
	while (ft_strlen(s1) - i >= ft_strlen(s2))
	{
		if (ft_memcmp((void *) s1 + i, (void *) s2, ft_strlen(s2)) == 0)
			return ((char *) s1 + i);
		i++;
	}
	return (0);
}
