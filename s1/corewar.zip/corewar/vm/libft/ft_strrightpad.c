/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrightpad.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbenhabb <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/12 18:24:11 by sbenhabb          #+#    #+#             */
/*   Updated: 2013/12/15 11:11:27 by sbenhabb         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strrightpad(char *str, int padding)
{
	int		i;
	int		j;
	char	*new;

	j = 0;
	i = ft_strlen(str);
	new = ft_strnew(ft_max(i, padding));
	while (j < i)
	{
		new[j] = str[j];
		j++;
	}
	while (j < padding)
		new[j++] = ' ';
	new[j] = 0;
	return (new);
}
