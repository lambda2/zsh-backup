/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbenhabb <sbenhabb@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/20 11:25:12 by sbenhabb          #+#    #+#             */
/*   Updated: 2013/12/28 21:22:03 by sbenhabb         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int		ft_isspace(char c);
static char		*ft_emptystring(void);

char			*ft_strtrim(const char *s)
{
	char		*str;
	size_t		begin;
	int			end;
	size_t		i;

	begin = 0;
	i = 0;
	if (ft_strlen(s) == 0)
		return (ft_emptystring());
	end = ft_strlen(s) - 1;
	if (end < 0)
		return ((char *) s);
	while ((int) begin < end && s[begin] != 0 && ft_isspace(s[begin]) == 1)
		begin++;
	while (end > (int) begin + 1 && end > 0 && ft_isspace(s[end]) == 1)
		end--;
	str = (char *) ft_memalloc(sizeof(char) * ((size_t) end - begin + 1));
	if ((int) begin < end)
	{
		while ((int) begin <= end)
			str[i++] = s[begin++];
	}
	str[i] = 0;
	return (str);
}

static char		*ft_emptystring(void)
{
	char	*str;

	str = (char *) ft_memalloc(sizeof(char *) * 1);
	str[0] = 0;
	return (str);
}

static int		ft_isspace(char c)
{
	if (c == ' ' || c == '\t' || c == '\n'
			|| c == '\v' || c == '\r' || c == '\f')
		return (1);
	else
		return (0);
}
