/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strmapi.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbenhabb <sbenhabb@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/20 10:46:11 by sbenhabb          #+#    #+#             */
/*   Updated: 2013/11/30 05:44:36 by sbenhabb         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strmapi(char const *s, char (*f)(unsigned int, char))
{
	char	*str;
	int		i;
	int		j;

	i = ft_strlen(s);
	j = 0;
	str = (char *) ft_memalloc(sizeof(char *) * (i + 1));
	while (j < i)
	{
		str[j] = (*f) (j, s[j]);
		j++;
	}
	str[j] = 0;
	return (str);
}
