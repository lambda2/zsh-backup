/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstmap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbenhabb <sbenhabb@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/20 23:40:59 by sbenhabb          #+#    #+#             */
/*   Updated: 2013/11/30 05:50:53 by sbenhabb         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

t_list	*ft_lstmap(t_list *lst, t_list *(*f)(t_list *elem))
{
	t_list	*listmap;
	t_list	*temp;
	t_list	*newelem;

	listmap = 0;
	while (lst != 0)
	{
		newelem = (t_list *) malloc(sizeof(t_list *));
		if (newelem == 0)
			return (0);
		newelem = (t_list *)(*f)(lst);
		if (listmap == 0)
		{
			listmap = newelem;
			temp = newelem;
		}
		else
		{
			temp->next = newelem;
			temp = newelem;
		}
		lst = lst->next;
	}
	return (listmap);
}
