/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   processes.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbenhabb <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/12 03:01:27 by sbenhabb          #+#    #+#             */
/*   Updated: 2014/01/12 03:54:17 by sbenhabb         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "vm.h"

t_process	*new_process(t_champion *champion, char *val, t_process *processes)
{
	t_process		*process;

	process = (t_process *) malloc(sizeof(t_process));
	process->champion = champion;
	//process->pc = 
	process->carry = 1;
	process->alive = 0;
	process->next = 0;
	process->prev = 0;
	if (processes)
	{
		process->next = processes;
		processes->prev = process;
	}
	return (process);
}

t_process	*remove_from_list(t_process **processes, t_process *process)
{
	t_process		*tmp;

	if (process->next && process->prev)
	{
		process->next->prev = process->prev;
		process->prev->next = process->next;
		tmp = process->next;
	}
	else if (process->next)
	{
		process->next->prev = 0;
		tmp = process->next;
		*processes = tmp;
	}
	else if (process->prev)
	{
		process->prev->next = 0;
		tmp = process->prev;
	}
	else
		*processes = 0;
	process = 0;
	free(process);
	return (tmp);
}
