/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checks.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbenhabb <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/11 23:42:29 by sbenhabb          #+#    #+#             */
/*   Updated: 2014/01/12 03:50:32 by sbenhabb         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# include "vm.h"

t_vm		*check_round(t_vm *vm)
{
	t_process		*process;

	process = vm->processes;
	while (process)
	{
		//if (!process->alive)
		//	kill_process(process);
		process = process->next;
	}
	return (vm);
}

void		check_rounds(t_vm *vm)
{
	if (vm->round % MAX_CHECKS == 0 && vm->round != 0)
	{
		vm->round = 0;
		vm->cycles_to_die -= 1;
	}
	else
		vm->round++;
}

void		check_lives(t_vm *vm)
{
	// verifier que les processus sont en vie, sinon kill
	if (vm->lives >= NBR_LIVE)
	{
		vm->cycles_to_die -= CYCLE_DELTA;
		vm->round = 0;
	}
	else
		check_rounds(vm);
	vm->lives = 0;
}
