/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   vm.h                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbenhabb <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/11 23:38:57 by sbenhabb          #+#    #+#             */
/*   Updated: 2014/01/12 06:07:20 by sbenhabb         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

#ifndef VM_H
# define VM_H

# include "libft/libft.h"

# define CYCLE_TO_DIE	1500
# define CYCLE_DELTA	50
# define NBR_LIVE		21
# define MAX_CHECKS		5

# define MAX_PLAYERS	4
# define MEM_SIZE		(4 * 1024)
# define IDX_MOD		(MEM_SIZE / 8)
# define CHAMP_MAX_SIZE	(MEM_SIZE / 6)

# define REG_SIZE		4
# define REG_NUMBER		16

typedef struct			s_champion
{
	int					id;
	char				*name;
}						t_champion;

typedef struct			s_process
{
	unsigned long		pc;
	t_champion			*champion;
	char				registers[REG_NUMBER * REG_SIZE];
	struct s_process	*next;
	struct s_process	*prev;
	int					alive;
	int					carry;
}						t_process;

typedef struct			s_vm
{
	int					round;
	int					total_rounds;
	int					lives;
	int					cycles_to_die;
	t_process			*processes;
	char				*memory;
	int					dump_threshold;
	t_champion			*champions;
}						t_vm;

t_vm			*init(void);
t_vm			*parser(int argc, char **argv, t_vm *vm);

t_vm			*add_champion(t_vm *vm, int nb, char *name, int id);

void			vm_dump(t_vm *vm);

#endif
