/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   vm_main.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbenhabb <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/30 08:03:33 by sbenhabb          #+#    #+#             */
/*   Updated: 2014/01/12 06:14:16 by sbenhabb         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "vm.h"

int			main(int argc, char **argv)
{
	t_vm		*vm;
	int			i;

	i = 0;
	vm = init();
	vm = parser(argc, argv, vm);
	if (vm->dump_threshold > -1)
	vm_dump(vm);
	printf("Champions :\n");
	while (i < MAX_PLAYERS)
	{
		if (vm->champions[i].id > 0)
			printf("%s player %d\n", vm->champions[i].name, vm->champions[i].id);
		i++;
	}
	return (0);
	/*
	int			i;
	int			play;

	i = 1;
	play = 1;
	while (i < argc)
		// Charger le processus argv[i]
	while (play)
	{
		// mettre le live de tous les processus a 0
		//
		// autoriser des tours d'actions
		//
		// verifier le live de chaque processus et les kill si le live != 0
	}
	*/
}
