/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   champions.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbenhabb <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/12 04:33:30 by sbenhabb          #+#    #+#             */
/*   Updated: 2014/01/12 06:17:54 by sbenhabb         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "vm.h"

static int		id_is_free(int id, t_vm *vm);

t_vm			*add_champion(t_vm *vm, int nb, char *name, int id)
{
	if (id == -1 || id > MAX_PLAYERS)
	{
		id = 1;
		while (!id_is_free(id, vm))
			id++;
	}
	vm->champions[nb].id = id;
	vm->champions[nb].name = ft_strdup(name);
	return (vm);
}

static int		id_is_free(int id, t_vm *vm)
{
	int		i;
	int		available;

	available = 1;
	i = 0;
	while (i < MAX_PLAYERS)
	{
		if (vm->champions[i].id == id)
			available = 0;
		i++;
	}
	return (available);
}
